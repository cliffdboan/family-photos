
SECRET_KEY = '8124876b9d9569762ca387771b0878f1907007bfdaa5bfb444aed35a74bf7589'

DATABASE_URL = "sqlite+pysqlite:///family_photos.db"
